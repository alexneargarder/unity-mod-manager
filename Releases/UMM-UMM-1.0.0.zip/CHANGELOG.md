v1.0.0 (v0.32.4 of base UMM repo)
Released on Thunderstore