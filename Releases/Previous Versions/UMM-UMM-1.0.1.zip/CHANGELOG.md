## v1.0.1 (v0.32.4 of base UMM repo)
- Better mod icon

## v1.0.0 (v0.32.4 of base UMM repo)
- Released on Thunderstore